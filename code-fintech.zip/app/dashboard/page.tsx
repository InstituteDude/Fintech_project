"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { getCurrentUser, logoutUser, type User } from "@/lib/auth"
import { getPengajuanByUserId, getPengajuanStats, type Pengajuan } from "@/lib/pengajuan"
import { LogOut, Plus, TrendingUp, Clock, CheckCircle, XCircle } from "lucide-react"

export default function DashboardPage() {
  const router = useRouter()
  const [user, setUser] = useState<User | null>(null)
  const [pengajuanList, setPengajuanList] = useState<Pengajuan[]>([])
  const [stats, setStats] = useState({
    total: 0,
    pending: 0,
    approved: 0,
    funded: 0,
    rejected: 0,
    totalAmount: 0,
  })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const currentUser = getCurrentUser()
    if (!currentUser) {
      router.push("/login")
      return
    }

    setUser(currentUser)
    const userPengajuan = getPengajuanByUserId(currentUser.id)
    setPengajuanList(userPengajuan)
    setStats(getPengajuanStats(currentUser.id))
    setLoading(false)
  }, [router])

  const handleLogout = () => {
    logoutUser()
    router.push("/")
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Memuat...</p>
      </div>
    )
  }

  if (!user) {
    return null
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(amount)
  }

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("id-ID", {
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const getStatusBadge = (status: string) => {
    const statusConfig: Record<string, { bg: string; text: string; label: string }> = {
      pending: { bg: "bg-yellow-100", text: "text-yellow-800", label: "Menunggu" },
      approved: { bg: "bg-blue-100", text: "text-blue-800", label: "Disetujui" },
      funded: { bg: "bg-green-100", text: "text-green-800", label: "Didanai" },
      rejected: { bg: "bg-red-100", text: "text-red-800", label: "Ditolak" },
    }

    const config = statusConfig[status] || statusConfig.pending
    return (
      <span className={`px-3 py-1 rounded-full text-sm font-medium ${config.bg} ${config.text}`}>{config.label}</span>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-primary">Gotong Royong & Invest</h1>
            <p className="text-sm text-muted-foreground">Dashboard</p>
          </div>
          <div className="flex items-center gap-4">
            <div className="text-right">
              <p className="font-medium text-foreground">{user.name}</p>
              <p className="text-xs text-muted-foreground capitalize">
                {user.type === "peminjam" ? "Peminjam" : "Investor"}
              </p>
            </div>
            <Button variant="outline" size="sm" onClick={handleLogout} className="gap-2 bg-transparent">
              <LogOut className="w-4 h-4" />
              Keluar
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-foreground mb-2">Selamat datang, {user.name}!</h2>
          <p className="text-muted-foreground">Kelola pengajuan pinjaman Anda di sini</p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-4 mb-8">
          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Total Pengajuan</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{stats.total}</div>
              <p className="text-xs text-muted-foreground mt-1">pengajuan</p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Menunggu
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-yellow-600">{stats.pending}</div>
              <p className="text-xs text-muted-foreground mt-1">dalam review</p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                Disetujui
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">{stats.approved}</div>
              <p className="text-xs text-muted-foreground mt-1">pengajuan</p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Didanai
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">{stats.funded}</div>
              <p className="text-xs text-muted-foreground mt-1">pengajuan</p>
            </CardContent>
          </Card>

          <Card className="border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                <XCircle className="w-4 h-4" />
                Ditolak
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-red-600">{stats.rejected}</div>
              <p className="text-xs text-muted-foreground mt-1">pengajuan</p>
            </CardContent>
          </Card>
        </div>

        {/* Total Amount Card */}
        <Card className="border-border mb-8 bg-gradient-to-br from-primary/5 to-primary/10">
          <CardHeader>
            <CardTitle>Total Jumlah Pengajuan</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold text-primary">{formatCurrency(stats.totalAmount)}</div>
            <p className="text-sm text-muted-foreground mt-2">Dari semua pengajuan Anda</p>
          </CardContent>
        </Card>

        {/* Action Button */}
        <div className="mb-8">
          <Link href="/dashboard/pengajuan-baru">
            <Button size="lg" className="gap-2">
              <Plus className="w-5 h-5" />
              Buat Pengajuan Baru
            </Button>
          </Link>
        </div>

        {/* Pengajuan List */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle>Daftar Pengajuan</CardTitle>
            <CardDescription>Semua pengajuan pinjaman Anda</CardDescription>
          </CardHeader>
          <CardContent>
            {pengajuanList.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-muted-foreground mb-4">Belum ada pengajuan</p>
                <Link href="/dashboard/pengajuan-baru">
                  <Button variant="outline">Buat Pengajuan Pertama</Button>
                </Link>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-3 px-4 font-semibold text-foreground">Nama Usaha</th>
                      <th className="text-left py-3 px-4 font-semibold text-foreground">Jumlah</th>
                      <th className="text-left py-3 px-4 font-semibold text-foreground">Jangka Waktu</th>
                      <th className="text-left py-3 px-4 font-semibold text-foreground">Status</th>
                      <th className="text-left py-3 px-4 font-semibold text-foreground">Tanggal</th>
                      <th className="text-left py-3 px-4 font-semibold text-foreground">Aksi</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pengajuanList.map((pengajuan) => (
                      <tr key={pengajuan.id} className="border-b border-border hover:bg-muted/50 transition-colors">
                        <td className="py-3 px-4 text-foreground font-medium">{pengajuan.namaUsaha}</td>
                        <td className="py-3 px-4 text-foreground">{formatCurrency(pengajuan.jumlahPinjaman)}</td>
                        <td className="py-3 px-4 text-foreground">{pengajuan.jangkaWaktu} bulan</td>
                        <td className="py-3 px-4">{getStatusBadge(pengajuan.status)}</td>
                        <td className="py-3 px-4 text-sm text-muted-foreground">{formatDate(pengajuan.createdAt)}</td>
                        <td className="py-3 px-4">
                          <Link href={`/dashboard/pengajuan/${pengajuan.id}`}>
                            <Button variant="outline" size="sm">
                              Lihat Detail
                            </Button>
                          </Link>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
