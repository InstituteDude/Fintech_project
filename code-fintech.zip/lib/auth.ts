// Simple auth utility using localStorage
export interface User {
  id: string
  email: string
  name: string
  type: "peminjam" | "investor"
  createdAt: string
}

export interface AuthState {
  user: User | null
  isAuthenticated: boolean
}

const USERS_KEY = "modaumkm_users"
const CURRENT_USER_KEY = "modaumkm_current_user"

export function generateId(): string {
  return Math.random().toString(36).substring(2, 11)
}

export function registerUser(email: string, password: string, name: string, type: "peminjam" | "investor"): User {
  const users = JSON.parse(localStorage.getItem(USERS_KEY) || "[]")

  if (users.some((u: any) => u.email === email)) {
    throw new Error("Email sudah terdaftar")
  }

  const newUser: User = {
    id: generateId(),
    email,
    name,
    type,
    createdAt: new Date().toISOString(),
  }

  users.push({ ...newUser, password })
  localStorage.setItem(USERS_KEY, JSON.stringify(users))

  return newUser
}

export function initializeDemoUser(): void {
  const users = JSON.parse(localStorage.getItem(USERS_KEY) || "[]")

  // Check if demo user already exists
  const demoUserExists = users.some((u: any) => u.email === "demo@example.com")

  if (!demoUserExists) {
    const demoUser: User = {
      id: generateId(),
      email: "demo@example.com",
      name: "Demo User",
      type: "peminjam",
      createdAt: new Date().toISOString(),
    }

    users.push({ ...demoUser, password: "demo123" })
    localStorage.setItem(USERS_KEY, JSON.stringify(users))
  }
}

export function loginUser(email: string, password: string): User {
  const users = JSON.parse(localStorage.getItem(USERS_KEY) || "[]")
  const user = users.find((u: any) => u.email === email && u.password === password)

  if (!user) {
    throw new Error("Email atau password salah")
  }

  const { password: _, ...userWithoutPassword } = user
  localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(userWithoutPassword))

  return userWithoutPassword
}

export function getCurrentUser(): User | null {
  const user = localStorage.getItem(CURRENT_USER_KEY)
  return user ? JSON.parse(user) : null
}

export function logoutUser(): void {
  localStorage.removeItem(CURRENT_USER_KEY)
}

export function isAuthenticated(): boolean {
  return getCurrentUser() !== null
}
