"use client"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { getCurrentUser } from "@/lib/auth"
import { getPengajuanById, type Pengajuan } from "@/lib/pengajuan"
import { ArrowLeft } from "lucide-react"

export default function PengajuanDetailPage() {
  const router = useRouter()
  const params = useParams()
  const [user, setUser] = useState<any>(null)
  const [pengajuan, setPengajuan] = useState<Pengajuan | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const currentUser = getCurrentUser()
    if (!currentUser) {
      router.push("/login")
      return
    }

    setUser(currentUser)

    const pengajuanData = getPengajuanById(params.id as string)
    if (!pengajuanData) {
      router.push("/dashboard")
      return
    }

    setPengajuan(pengajuanData)
    setLoading(false)
  }, [router, params])

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Memuat...</p>
      </div>
    )
  }

  if (!pengajuan) {
    return null
  }

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
    }).format(amount)
  }

  const formatDate = (date: string) => {
    return new Date(date).toLocaleDateString("id-ID", {
      year: "numeric",
      month: "long",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    })
  }

  const getStatusBadge = (status: string) => {
    const statusConfig: Record<string, { bg: string; text: string; label: string }> = {
      pending: { bg: "bg-yellow-100", text: "text-yellow-800", label: "Menunggu Review" },
      approved: { bg: "bg-blue-100", text: "text-blue-800", label: "Disetujui" },
      funded: { bg: "bg-green-100", text: "text-green-800", label: "Didanai" },
      rejected: { bg: "bg-red-100", text: "text-red-800", label: "Ditolak" },
    }

    const config = statusConfig[status] || statusConfig.pending
    return (
      <span className={`px-4 py-2 rounded-full text-sm font-semibold ${config.bg} ${config.text}`}>{config.label}</span>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-card border-b border-border sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
          <div>
            <h1 className="text-2xl font-bold text-primary">ModaUMKM</h1>
            <p className="text-sm text-muted-foreground">Detail Pengajuan</p>
          </div>
          <Link href="/dashboard">
            <Button variant="outline" size="sm" className="gap-2 bg-transparent">
              <ArrowLeft className="w-4 h-4" />
              Kembali
            </Button>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Status Card */}
        <Card className="border-border mb-8 bg-gradient-to-r from-primary/5 to-primary/10">
          <CardContent className="pt-6">
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-3xl font-bold text-foreground mb-2">{pengajuan.namaUsaha}</h2>
                <p className="text-muted-foreground">ID Pengajuan: {pengajuan.id}</p>
              </div>
              <div>{getStatusBadge(pengajuan.status)}</div>
            </div>
          </CardContent>
        </Card>

        {/* Details Grid */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {/* Informasi Pinjaman */}
          <Card className="border-border">
            <CardHeader>
              <CardTitle>Informasi Pinjaman</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Jumlah Pinjaman</p>
                <p className="text-2xl font-bold text-primary">{formatCurrency(pengajuan.jumlahPinjaman)}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Jangka Waktu</p>
                <p className="text-lg font-semibold text-foreground">{pengajuan.jangkaWaktu} bulan</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Tujuan Pinjaman</p>
                <p className="text-lg font-semibold text-foreground capitalize">{pengajuan.tujuanPinjaman}</p>
              </div>
            </CardContent>
          </Card>

          {/* Timeline */}
          <Card className="border-border">
            <CardHeader>
              <CardTitle>Timeline</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Dibuat</p>
                <p className="text-sm font-semibold text-foreground">{formatDate(pengajuan.createdAt)}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground mb-1">Terakhir Diupdate</p>
                <p className="text-sm font-semibold text-foreground">{formatDate(pengajuan.updatedAt)}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Deskripsi */}
        <Card className="border-border">
          <CardHeader>
            <CardTitle>Deskripsi Usaha</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-foreground leading-relaxed whitespace-pre-wrap">{pengajuan.deskripsi}</p>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
