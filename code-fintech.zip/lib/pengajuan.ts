// Pengajuan (Loan Application) management
export interface Pengajuan {
  id: string
  userId: string
  namaUsaha: string
  deskripsi: string
  jumlahPinjaman: number
  jangkaWaktu: number // dalam bulan
  tujuanPinjaman: string
  status: "pending" | "approved" | "rejected" | "funded"
  createdAt: string
  updatedAt: string
}

const PENGAJUAN_KEY = "modaumkm_pengajuan"

export function createPengajuan(
  userId: string,
  data: Omit<Pengajuan, "id" | "userId" | "status" | "createdAt" | "updatedAt">,
): Pengajuan {
  const pengajuanList = JSON.parse(localStorage.getItem(PENGAJUAN_KEY) || "[]")

  const newPengajuan: Pengajuan = {
    ...data,
    id: Math.random().toString(36).substring(2, 11),
    userId,
    status: "pending",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  }

  pengajuanList.push(newPengajuan)
  localStorage.setItem(PENGAJUAN_KEY, JSON.stringify(pengajuanList))

  return newPengajuan
}

export function getPengajuanByUserId(userId: string): Pengajuan[] {
  const pengajuanList = JSON.parse(localStorage.getItem(PENGAJUAN_KEY) || "[]")
  return pengajuanList.filter((p: Pengajuan) => p.userId === userId)
}

export function getAllPengajuan(): Pengajuan[] {
  return JSON.parse(localStorage.getItem(PENGAJUAN_KEY) || "[]")
}

export function getPengajuanById(id: string): Pengajuan | null {
  const pengajuanList = JSON.parse(localStorage.getItem(PENGAJUAN_KEY) || "[]")
  return pengajuanList.find((p: Pengajuan) => p.id === id) || null
}

export function getPengajuanStats(userId: string) {
  const pengajuanList = getPengajuanByUserId(userId)

  return {
    total: pengajuanList.length,
    pending: pengajuanList.filter((p) => p.status === "pending").length,
    approved: pengajuanList.filter((p) => p.status === "approved").length,
    funded: pengajuanList.filter((p) => p.status === "funded").length,
    rejected: pengajuanList.filter((p) => p.status === "rejected").length,
    totalAmount: pengajuanList.reduce((sum, p) => sum + p.jumlahPinjaman, 0),
  }
}
